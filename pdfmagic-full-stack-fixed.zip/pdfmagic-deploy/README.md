# All In One File Converter — Full Stack

A privacy-first PDF & file conversion tool. All processing runs in your browser OR optionally on the Node.js backend.

## Features
- Merge PDF, Split PDF, Compress PDF
- PDF ↔ Images, Images → PDF
- PDF → Word (.docx)
- Excel ↔ PDF
- PDF → Excel (table extraction)
- **PDF Editor** ✏️ — Draw, Highlight, Line, Rect, Text, Eraser with full backend save

## Quick Start

```bash
npm install
npm start
```

Then open **http://localhost:3000**

## PDF Editor Backend API

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/pdfeditor/upload` | Upload PDF, get `sessionId` |
| POST | `/api/pdfeditor/save` | Send annotations JSON, get edited PDF download |
| DELETE | `/api/pdfeditor/session/:id` | Clean up session early |
| GET | `/api/pdfeditor/health` | Health check |

### Save Request Body
```json
{
  "sessionId": "uuid-from-upload",
  "annotations": {
    "1": [
      {
        "tool": "draw",
        "color": "#e63946",
        "size": 4,
        "points": [{"x": 100, "y": 200}, {"x": 150, "y": 220}],
        "canvasWidth": 816,
        "canvasHeight": 1056
      },
      {
        "tool": "text",
        "color": "#000000",
        "size": 4,
        "x": 50,
        "y": 80,
        "text": "Hello World",
        "canvasWidth": 816,
        "canvasHeight": 1056
      }
    ]
  }
}
```

### Annotation Tools
| Tool | Required Fields |
|------|----------------|
| `draw` | `points[]`, `color`, `size` |
| `highlight` | `points[]`, `color`, `size` (rendered at 35% opacity) |
| `line` | `x1`, `y1`, `x2`, `y2`, `color`, `size` |
| `rect` | `x1`, `y1`, `x2`, `y2`, `color`, `size` |
| `text` | `x`, `y`, `text`, `color`, `size` |
| `eraser` | `points[]`, `size` (renders white over content) |

## Deployment Notes
- Files auto-deleted from `outputs/` after 1 hour
- Sessions auto-expire after 2 hours
- Max upload size: 100MB per PDF
- No database required — sessions stored in memory

## Environment Variables
| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | Server port |

## Sign PDF Backend API

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/signpdf/upload` | Upload PDF, get `sessionId` |
| POST | `/api/signpdf/sign` | Send signature placements, get signed PDF |
| DELETE | `/api/signpdf/session/:id` | Clean up session early |
| GET | `/api/signpdf/health` | Health check |

### Sign Request Body
```json
{
  "sessionId": "uuid-from-upload",
  "placements": [
    {
      "page": 1,
      "x": 300,
      "y": 680,
      "w": 180,
      "h": 60,
      "canvasWidth": 816,
      "canvasHeight": 1056,
      "sigDataURL": "data:image/png;base64,..."
    }
  ]
}
```

### Signature Creation Modes (all handled in-browser)
| Mode | How it works |
|------|-------------|
| Draw | HTML5 Canvas freehand drawing pad |
| Type | Name rendered in cursive font (Dancing Script / Caveat / Pacifico) to canvas PNG |
| Upload | User uploads PNG/JPG; drawn onto canvas for normalization |

All three modes produce a `sigDataURL` (PNG base64) sent to the backend for embedding.
